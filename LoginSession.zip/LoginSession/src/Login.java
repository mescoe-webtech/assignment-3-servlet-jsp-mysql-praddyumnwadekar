

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Login
 */
//@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
      	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String Uname = request.getParameter("UName");
		String pass = request.getParameter("pass");
		
		Boolean flag = false;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/signup","root", "root");
			PreparedStatement ps = con.prepareStatement("select * from student where username=? and password=?");
			ps.setString(1,Uname);
			ps.setString(2,pass);
			
			ResultSet rs = ps.executeQuery();
			flag = rs.next();
				
			if(flag==true) {
				HttpSession session = request.getSession();
				session.setAttribute("unm", Uname);
				RequestDispatcher rds = request.getRequestDispatcher("Home.jsp");
				rds.forward(request, response);
			}
			else {
				out.print("Username of Password is Wrong");
				RequestDispatcher rds = request.getRequestDispatcher("login.jsp");
				rds.include(request, response);
				}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	
	}

}
