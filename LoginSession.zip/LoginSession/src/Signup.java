

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Signup
 */
// @WebServlet("/Signup")
public class Signup extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String Fname = request.getParameter("FName");
		String Lname = request.getParameter("LName");
		String Email = request.getParameter("Email");
		String Uname = request.getParameter("UName");
		String pass = request.getParameter("pass");
		String gender = request.getParameter("Gender");
		String mob = request.getParameter("MobileNo");
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/signup","root", "root");
			PreparedStatement ps = con.prepareStatement("insert into student values(?,?,?,?,?,?,?)");
			ps.setString(1,Fname);
			ps.setString(2,Lname);
			ps.setString(3,Email);
			ps.setString(4,Uname);
			ps.setString(5,pass);
			ps.setString(6,mob);
			ps.setString(7, gender);
			
			int i = ps.executeUpdate();
			if(i > 0) {
				out.println("You are Signup Successfully");
				out.print("<a href='login.jsp'>Click here for Login</a>");
			}
			else {
				out.print("Error!!");
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}

}
